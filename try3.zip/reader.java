package try3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class reader {
    private int id;
    private String firstName;
    private String lastName;
    private String middleName;
    private String address;
    private ArrayList<Book> bookList; // Список книг

    public reader(int id, String firstName, String lastName, String middleName, String address) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.address = address;
        this.bookList = new ArrayList<>();
    }

    public reader (int readerId){};
    @Override
    public String toString() {
        return "ID: " + id + ", Имя: " + firstName + ", Фамилия: " + lastName + ", Отчество: " + middleName + ", Адрес: " + address;
    }


    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getAddress() {
        return address;
    }

    public List<Book> getBooks() {
        return bookList;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setBooks(ArrayList<Book> bookList) {
        this.bookList = bookList;
    }
    public reader() {
        this.bookList = new ArrayList<>(); // Инициализация bookList в конструкторе
    }

    public void take(ArrayList<Book> books, librarywor librw, ArrayList<Book> bookList,ArrayList<Book> allbooks) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите ID читателя: ");
        int readerId = scanner.nextInt();
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите название книги:");
        String bookName = scan.nextLine();
        librw.gettoreader(this, bookName, books, allbooks,readerId);}

    public void giveback(ArrayList<Book> books, librarywor librw, ArrayList<Book> bookList,ArrayList<Book> allbooks) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите ID читателя: ");
        int readerId = scanner.nextInt();
        Scanner scann = new Scanner(System.in);
        System.out.println("Введите название книги:");
        String bookName = scann.nextLine();
        librw.backtolib(this, bookName, books,readerId,allbooks); // Передаем текущий объект reader
    }
}

