package try3;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.time.LocalDate;


public class librarywor {
    private int id;
    private String firstName;
    private String lastName;
    private String middleName;
    private String address;
    //private List<Book> books; // Список книг



    //конструктор класса
    public librarywor(int id, String firstName, String lastName, String middleName, String address) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.address = address;
        //this.books = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void findbook(ArrayList<Book> books){
        Scanner s = new Scanner(System.in);
        System.out.println("введите название книги, которую хотите найти:");
        String name = s.nextLine();
        for (Book book : books) {
            if (Objects.equals(book.getName(), name)) {
                System.out.println("Book: " + book);
            }
        }
    }
    /*public  void extractbook (ArrayList<Book> bookList,ArrayList<Book> books){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите id:");
        int id = scanner.nextInt();
        for (int i = 0; i < books.size(); i++) {
            if (id == books.get(i).getId()) {
                Book bookToRemove = books.get(i);
                books.remove(i);
                bookList.add(bookToRemove);
                for (Book book : bookList) {
                    System.out.println(book);
                break;
            }
        }}
    }*/

    /*public void backbook(ArrayList<Book> bookList,ArrayList<Book> books){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите id:");
        int id = scanner.nextInt();
        for (int i = 0; i < bookList.size(); i++) {
            if (id == bookList.get(i).getId()) {
                Book bookToRemove = bookList.get(i);
                bookList.remove(i);
                books.add(bookToRemove);
                for (Book book : books) {
                    System.out.println(book);
                    break;}
            }
        }
    }*/
    public void fileconv(ArrayList<Book> books) {
        try {
            FileWriter file = new FileWriter("list_of_books.txt", false);
            for (Book value : books) {
                file.write(value.toString() + "\n");
            }
            file.close();
            System.out.println("Файл успешно создан: list_of_books.txt");
        } catch (IOException e) {
            System.out.println("Ошибка при создании файла: " + e.getMessage());
            e.printStackTrace();
        }
    }
    // Создаем список читателей
    //ArrayList<reader> readerList = new ArrayList<>();

    public void gettoreader(reader red, String bookName, ArrayList<Book> books, ArrayList<Book> allbooks, int readerId) {
        // Получаем bookList из переданного объекта reader
        ArrayList<Book> bookList = (ArrayList<Book>) red.getBooks();

        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getName().equals(bookName)) {
                Book bookToRemove = books.remove(i);
                bookList.add(bookToRemove); // Добавляем книгу в список книг читателя
                allbooks.add(bookToRemove);
                System.out.println("Книга \"" + bookToRemove.getName() + "\" успешно выдана читателю.");
                System.out.println("Список книг читателя: " + bookList);
                System.out.println("Все взятые книги: " + allbooks);
                return;
            }
        }
        System.out.println("Книга с таким названием не найдена.");
    }


    public void backtolib(reader red, String bookName, ArrayList<Book> books, int readerId, ArrayList<Book> allbooks) {
       // reader red = new reader(readerId);
        ArrayList<Book> bookList = (ArrayList<Book>) red.getBooks();
        for (int i = 0; i < red.getBooks().size(); i++) {
            if (red.getBooks().get(i).getName().equals(bookName)) {
                Book bookToRemove = red.getBooks().remove(i); // Удаляем книгу из списка книг читателя
                books.add(bookToRemove);
                allbooks.remove(bookToRemove);
                System.out.println("Книга \"" + bookToRemove.getName() + "\" успешно возвращена в библиотеку.");
                System.out.println("Все взятые книги"+ allbooks);

                return;
            }
        }
        System.out.println("Книга с таким названием не найдена.");
    }

    public void returntodate(reader red,ArrayList<Book> bookList,ArrayList<reader> readerList){
        //ArrayList<Book> bookList = (ArrayList<Book>) red.getBooks();
        LocalDate currentDate = LocalDate.now();
        LocalDate futureDate = currentDate.plusWeeks(3);

        System.out.println("Введите имя читателя: ");
        Scanner sc = new Scanner(System.in);
        String nome = sc.nextLine();
        for (reader reader : readerList) {
                if (reader.getFirstName().equals(nome)){
                    ArrayList<Book> readerBooks = (ArrayList<Book>) red.getBooks();
                    System.out.println("Уважаемый " + nome+ "верните книги" + readerBooks + "до "+ futureDate);
                    //System.out.println("Books for reader with ID " + readerId + ":" + readerBooks);
                    return;
                }
            }

        }


    }