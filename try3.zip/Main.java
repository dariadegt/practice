package try3;
import java.util.ArrayList;
import java.util.Scanner;
public class Main {

        public static void main(String[] args) {
            ArrayList<Book> books = new ArrayList<>();
            ArrayList<reader> readers = new ArrayList<>();
            ArrayList<Book> bookList = new ArrayList<>();
            ArrayList<Book> allbookslist = new ArrayList<>();
            librarywor libwork = new librarywor(10, "Maria", "Berttys", "Charles", "Library Address");
            manager libManager = new manager(21, "John", "Doe", "", "Library Address");
            reader red = new reader(31, "Lizer", "Davidson", "okke", "cool address str 2");

            Scanner scanner = new Scanner(System.in);

            int roleChoice;
            do {
                System.out.println("Выберите роль:");
                System.out.println("1. Библиотекарь");
                System.out.println("2. Менеджер");
                System.out.println("3. Читатель");
                System.out.println("4. Выход");
                roleChoice = scanner.nextInt();

                switch (roleChoice) {
                    case 1:
                        librarianActions(libwork, books, bookList, readers, red, readers);
                        break;
                    case 2:
                        managerActions(libManager, books, readers,bookList,red);
                        break;
                    case 3:
                        readerActions(red,books,bookList,libwork,allbookslist);

                    case 4:
                        System.out.println("До свидания!");
                        break;
                    default:
                        System.out.println("Некорректный выбор роли. Попробуйте снова.");
                }
            } while (roleChoice != 4);
        }

    private static void librarianActions(librarywor libwork, ArrayList<Book> books, ArrayList<Book> booklist, ArrayList<reader> readerList, reader red, ArrayList<reader> readers) {
        Scanner scanner = new Scanner(System.in);
        int choice = -1; // Инициализируем переменную для начального значения
        while (choice != 0) { // Повторяем, пока пользователь не выберет выход
            System.out.println("Выберите действие:");
            //System.out.println("1. Выдать книгу читателю ");
            //System.out.println("2. Вернуть книгу в библиотеку");
            System.out.println("1. Найти книгу");
            System.out.println("2. Переписать список книг в файл");
            System.out.println("3. Сообщить, когда надо вернуть книги");
            System.out.println("0. Выход");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    libwork.findbook(books);
                    break;
                case 2:
                    libwork.fileconv(books);
                    break;
                case 3:
                    libwork.returntodate(red,booklist,readers);
                case 0:
                    System.out.println("До свидания!");
                    break;
                default:
                    System.out.println("Некорректный выбор. Попробуйте снова.");
            }
        }
    }

    private static void managerActions(manager libManager, ArrayList<Book> books, ArrayList<reader> readers,ArrayList<Book> bookList,reader red) {
        Scanner scanner = new Scanner(System.in);
        int choice = -1; // Инициализируем переменную для начального значения
        while (choice != 0) { // Повторяем, пока пользователь не выберет выход
            System.out.println("Выберите действие:");
            System.out.println("1. Добавить книгу");
            System.out.println("2. Удалить книгу");
            System.out.println("3. Найти книгу по категории");
            System.out.println("4. Подсчитать количество книг");
            System.out.println("5. Показать список книг читателя");
            //System.out.println("5. Сортировать книги по году издания (по возрастанию)");
            //System.out.println("6. Сортировать книги по году издания (по убыванию)");
            System.out.println("6. Добавить читателя в систему");
            System.out.println("0. Выход");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    libManager.add(books);
                    break;
                case 2:
                    libManager.remove(books);
                    break;
                case 3:
                    libManager.findoncat(books);
                    break;
                case 4:
                    libManager.count(books,red);
                    break;
                /*case 5:
                    libManager.sortBooksByYearAscending(books);
                    break;
                case 6:
                    libManager.sortBooksByYearDescending(books);
                    break;*/
                case 5:
                    libManager.addreader(readers);
                    break;
                case 6:
                    libManager.readerbooks(red,readers,bookList);
                    break;
                case 0:
                    System.out.println("До свидания!");
                    break;
                default:
                    System.out.println("Некорректный выбор. Попробуйте снова.");
            }
        }
    }

    private static void readerActions(reader red, ArrayList<Book> books, ArrayList<Book> bookList,librarywor libwork,ArrayList<Book> allbookslist){
        Scanner scanner = new Scanner(System.in);
        int choice = -1; // Инициализируем переменную для начального значения
        while (choice != 0) { // Повторяем, пока пользователь не выберет выход
            System.out.println("Выберите действие:");
            System.out.println("1. Забрать книгу из библиотеки ");
            System.out.println("2. Вернуть книгу в библиотеку");
            System.out.println("0. Выход");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    red.take(books,libwork,bookList,allbookslist);
                    break;
                case 2:
                    red.giveback(books,libwork,bookList,allbookslist);
                    break;
    }
        }
        }
}
/*    Идентификатор: 101
        Имя: "Война и мир"
        Автор: Лев Толстой
        Издание: Первое
        Издатель: АСТ
        Год издания: 1869
        Категория: Роман

    Идентификатор: 102
        Имя: "1984"
        Автор: Джордж Оруэлл
        Издание: Первое
        Издатель: Синдбад
        Год издания: 1949
        Категория: Дистопия

    Идентификатор: 103
        Имя: "Преступление и наказание"
        Автор: Фёдор Достоевский
        Издание: Второе
        Издатель: Эксмо
        Год издания: 1866
        Категория: Роман

    Идентификатор: 104
        Имя: "Гарри Поттер и философский камень"
        Автор: Дж. К. Роулинг
        Издание: Первое
        Издатель: Росмэн-Пресс
        Год издания: 1997
        Категория: Фэнтези

    Идентификатор: 105
        Имя: "Мастер и Маргарита"
        Автор: Михаил Булгаков
        Издание: Третье
        Издатель: Издательство "Проспект"
        Год издания: 1967
        Категория: Роман

    Идентификатор: 106
        Имя: "Убийство в Восточном экспрессе"
        Автор: Агата Кристи
        Издание: Первое
        Издатель: Московский рабочий
        Год издания: 1934
        Категория: Детектив

    Идентификатор: 107
        Имя: "Над пропастью во ржи"
        Автор: Джером Д. Сэлинджер
        Издание: Первое
        Издатель: Эксмо
        Год издания: 1951
        Категория: Роман */
