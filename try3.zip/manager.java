package try3;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class manager {
        private int id;
        private String firstName;
        private String lastName;
        private String middleName;
        private String address;
        private ArrayList<reader> readerlist;
        private ArrayList<Book> allbooks;



    //конструктор класса
    public manager(int id, String firstName, String lastName, String middleName, String address) {
            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.middleName = middleName;
            this.address = address;
        }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void add(ArrayList<Book> books){
        Scanner scanner = new Scanner(System.in);

        int id;
        while (true) {
            System.out.println("Введите id (для выхода введите 0):");
            id = scanner.nextInt();
            if (id == 0) {
                break;
            }
            scanner.nextLine(); // Считываем символ новой строки после nextInt(), чтобы избежать проблемы с переходом на следующую строку

            System.out.println("Введите имя:");
            String name = scanner.nextLine();

            System.out.println("Введите автора:");
            String author = scanner.nextLine();

            System.out.println("Введите издание:");
            String edition = scanner.nextLine();

            System.out.println("Введите издателя:");
            String publisher = scanner.nextLine();

            System.out.println("Введите год издания:");
            int year = scanner.nextInt();

            scanner.nextLine(); // Считываем символ новой строки после nextInt(), чтобы избежать проблемы с переходом на следующую строку

            System.out.println("Введите категорию:");
            String category = scanner.nextLine();

            // Создаем новый объект книги и добавляем его в список книг
            Book newBook = new Book(id, name, author, edition, publisher, year, category);
            books.add(newBook);

            System.out.println("Книга успешно добавлена!");
        }
    }
    public void remove(ArrayList<Book> books){
        Scanner s = new Scanner(System.in);
        System.out.println("введите id книги, которую хотите удалить:");
        int n = s.nextInt();
        for(int i=0;i<books.size();i++){
            if(books.get(i).getId()==n){
                books.remove(books.get(i));
            }
        }

    }
    public void findoncat(ArrayList<Book> books){
        Scanner s = new Scanner(System.in);
        System.out.println("введите категорию книги:");
        String category = s.nextLine();
        for (Book book : books) {
            if (Objects.equals(book.getCategory(), category)) {
                System.out.println("категория" + category + "книги" + book);
            }
        }
    }
    public void count(ArrayList<Book> books, reader red) {
        ArrayList<Book> bookList = (ArrayList<Book>) red.getBooks(); // Получаем bookList из reader
        System.out.println("Хэш-код объекта bookList: " + System.identityHashCode(bookList));

        if (bookList.isEmpty()) {
            System.out.println("Книги еще не взяли. Количество: 0");
        } else {
            System.out.println("Книг взяли: " + bookList.size());
        }

        System.out.println("Книг доступно: " + books.size());
    }


    public void readerbooks(reader red,ArrayList<reader> readerList,ArrayList<Book> bookList) {
        System.out.println("Введите id читателя:");
        Scanner sc = new Scanner(System.in);
        int readerId = sc.nextInt();
        for (reader reader : readerList) {
            if (reader.getId() == readerId) {
                ArrayList<Book> readerBooks = (ArrayList<Book>) red.getBooks();
                System.out.println("Books for reader with ID " + readerId + ":" + readerBooks);
                return;
            }
        }
        System.out.println("Reader with ID " + readerId + " not found.");
    }

    /*public void sortBooksByYearAscending(ArrayList<Book> books) {
        int n = books.size();
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (books.get(j).getYear() > books.get(j+1).getYear()) {
                    // Обмен элементов
                    Book temp = books.get(j);
                    books.set(j, books.get(j+1));
                    books.set(j+1, temp);
                }
            }
        }
        System.out.println("Отсортированные книги по году издания (возрастание):");
        for (Book book : books) {
            System.out.println("Название: " + book.getName() + ", Год издания: " + book.getYear());
        }
    }
    public void sortBooksByYearDescending(ArrayList<Book> books) {
        int n = books.size();
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (books.get(j).getYear() < books.get(j+1).getYear()) {
                    // Обмен элементов
                    Book temp = books.get(j);
                    books.set(j, books.get(j+1));
                    books.set(j+1, temp);
                }
            }
        }
        System.out.println("Отсортированные книги по году издания (убывание):");
        for (Book book : books) {
            System.out.println("Название: " + book.getName() + ", Год издания: " + book.getYear());
        }
    }*/
    public void addreader(ArrayList<reader> readerList) {
        Scanner scanner = new Scanner(System.in);

        int id;
        while (true) {
            System.out.println("Введите id (для выхода введите 0):");
            id = scanner.nextInt();
            if (id == 0) {
                break;
            }
            scanner.nextLine(); // Считываем символ новой строки после nextInt(), чтобы избежать проблемы с переходом на следующую строку

            System.out.println("Введите имя:");
            String firstName = scanner.nextLine();

            System.out.println("Введите фамилию:");
            String lastName = scanner.nextLine();

            System.out.println("Введите отчество:");
            String middleName = scanner.nextLine();

            System.out.println("Введите адрес:");
            String address = scanner.nextLine();

            // Создаем новый объект читателя и добавляем его в список читателей
            reader newReader = new reader(id, firstName, lastName, middleName, address);
            readerList.add(newReader);

            System.out.println("Читатель успешно добавлен!");
        }

        // Выводим список добавленных читателей
        System.out.println("Список читателей:"+ readerList);

    }
}

