package try3;

import java.util.ArrayList;
import java.util.Objects;

public class Book {
    private int id;
    private String name;
    private String author;
    private String edition;
    private String publisher;
    private int year;
    private String category;
    private boolean available; // Наличие книги
    private final ArrayList<Book> books;
    //private ArrayList<Book> bookList;

    public Book(int id, String name, String author, String edition, String publisher, int year, String category) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.edition = edition;
        this.publisher = publisher;
        this.year = year;
        this.category = category;
        this.available = true; // Изначально книга доступна
        this.books = new ArrayList<>();
    }
    @Override
    public String toString() {
        return "Название: " + this.name + ", Автор: " + this.author + ", Год издания: " + this.year;
    }

    // Геттеры и сеттеры
    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    }
